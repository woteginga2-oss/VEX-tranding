'use client';

import { useEffect, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { Localize } from '@deriv-com/translations';
import { useDigitsTrading } from '../../hooks/use-digits-trading';
import { useDerivWSContext } from '@/components/custom/deriv-ws-provider';
import { useLogoSrc } from '@/components/custom/logo-src-provider';
import { Header } from '@/components/custom/header';
import { ThemeToggle } from '@/components/custom/theme-toggle';
import { Footer } from '@/components/custom/footer';
import { useAppTranslations } from '@/components/custom/i18n-provider';
import Link from 'next/link';
import { PositionsTable } from '@/components/custom/positions-table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { getSymbolDisplayName } from '@/lib/active-symbols-display-names';
import type { ClosedPosition } from '@/hooks/use-closed-positions';

const DIGIT_CONTRACT_TYPES = [
  'DIGITMATCH',
  'DIGITDIFF',
  'DIGITOVER',
  'DIGITUNDER',
  'DIGITEVEN',
  'DIGITODD',
] as const;

function getDigitContractLabels(
  localize: (text: string) => string
): Record<string, string> {
  return {
    DIGITMATCH: localize('Digit Match'),
    DIGITDIFF: localize('Digit Differs'),
    DIGITOVER: localize('Digit Over'),
    DIGITUNDER: localize('Digit Under'),
    DIGITEVEN: localize('Digit Even'),
    DIGITODD: localize('Digit Odd'),
  };
}

function formatMoney(value: number): string {
  return value.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function formatDateTime(unixSeconds: number): string {
  if (!unixSeconds) return '—';
  return new Date(unixSeconds * 1000).toLocaleString(undefined, {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function computeRankingStats(closed: ClosedPosition[]) {
  let wins = 0;
  let losses = 0;
  let totalProfit = 0;
  let totalStake = 0;
  let bestProfit = 0;
  let worstLoss = 0;

  for (const pos of closed) {
    const profit = pos.sell_price - pos.buy_price;
    totalProfit += profit;
    totalStake += pos.buy_price;
    if (profit > 0) {
      wins += 1;
      if (profit > bestProfit) bestProfit = profit;
    } else if (profit < 0) {
      losses += 1;
      if (profit < worstLoss) worstLoss = profit;
    }
  }

  const total = closed.length;
  const winRate = total > 0 ? (wins / total) * 100 : 0;

  return {
    total,
    wins,
    losses,
    totalProfit,
    totalStake,
    winRate,
    bestProfit,
    worstLoss,
  };
}

export default function ReportsPage() {
  const logoSrc = useLogoSrc();
  const router = useRouter();
  const { localize } = useAppTranslations();
  const { ws, isConnected, isExhausted, auth } = useDerivWSContext();
  const { authState, accounts, activeAccount, login, signUp, logout, switchAccount } = auth;
  const trading = useDigitsTrading({
    ws,
    isConnected,
    isExhausted,
    isAuthenticated: !!auth.wsUrl,
    onAuthWSFailed: logout,
  });
  const digitContractLabels = getDigitContractLabels(localize);

  const digitOpenPositions = trading.openPositions.filter((p) =>
    (DIGIT_CONTRACT_TYPES as readonly string[]).includes(p.contract_type)
  );
  const digitClosedPositions = trading.closedPositions.filter((p) =>
    (DIGIT_CONTRACT_TYPES as readonly string[]).includes(p.contract_type)
  );

  const latestOperations = useMemo(
    () => digitClosedPositions.slice(0, 15),
    [digitClosedPositions]
  );

  const ranking = useMemo(
    () => computeRankingStats(digitClosedPositions),
    [digitClosedPositions]
  );

  useEffect(() => {
    if (authState === 'unauthenticated' || authState === 'error') {
      router.replace('/');
    }
  }, [authState, router]);

  if (authState !== 'authenticated') {
    return (
      <main className="flex flex-col bg-background items-center justify-center min-h-dvh">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </main>
    );
  }

  const isPositive = ranking.totalProfit >= 0;

  return (
    <main className="flex flex-col bg-background max-lg:h-dvh max-lg:overflow-y-auto lg:min-h-dvh">
      <Header
        authState={authState}
        accounts={accounts}
        activeAccount={activeAccount}
        onLogin={login}
        onSignUp={signUp}
        onLogout={logout}
        onSwitchAccount={switchAccount}
        logoSrc={logoSrc}
        actions={<ThemeToggle />}
      />

      <div className="flex-1 w-full max-w-7xl mx-auto px-3 py-4 sm:px-4 sm:py-6 pb-14">
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-4"
        >
          <span className="text-base leading-none">←</span>
          <span>
            <Localize i18n_default_text="Back" />
          </span>
        </Link>

        <Card className="mb-4">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <span aria-hidden="true">🏆</span>
              Ranking de operações
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              <div className="rounded-lg bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">Operações (dígitos)</p>
                <p className="mt-1 text-2xl font-bold tabular-nums">{ranking.total}</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">Vitórias</p>
                <p className="mt-1 text-2xl font-bold tabular-nums text-emerald-500">
                  {ranking.wins}
                </p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">Derrotas</p>
                <p className="mt-1 text-2xl font-bold tabular-nums text-destructive">
                  {ranking.losses}
                </p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">Taxa de acerto</p>
                <p className="mt-1 text-2xl font-bold tabular-nums">
                  {ranking.winRate.toFixed(1)}%
                </p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">Lucro / Prejuízo</p>
                <p
                  className={cn(
                    'mt-1 text-2xl font-bold tabular-nums',
                    isPositive ? 'text-emerald-500' : 'text-destructive'
                  )}
                >
                  {isPositive ? '+' : ''}
                  {formatMoney(ranking.totalProfit)}
                </p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">Abertas agora</p>
                <p className="mt-1 text-2xl font-bold tabular-nums">
                  {digitOpenPositions.length}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-lg border border-border/60 p-3">
                <p className="text-xs text-muted-foreground">Melhor operação</p>
                <p className="mt-1 text-lg font-semibold tabular-nums text-emerald-500">
                  +{formatMoney(ranking.bestProfit)}
                </p>
              </div>
              <div className="rounded-lg border border-border/60 p-3">
                <p className="text-xs text-muted-foreground">Pior operação</p>
                <p className="mt-1 text-lg font-semibold tabular-nums text-destructive">
                  {formatMoney(ranking.worstLoss)}
                </p>
              </div>
            </div>

            <p className="text-xs text-muted-foreground">
              Resumo da conta autenticada com base nas até 500 operações
              concluídas carregadas pela API (apenas contratos de dígitos). Não
              é um ranking público entre utilizadores.
            </p>
          </CardContent>
        </Card>

        <Card className="mb-4">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <span aria-hidden="true">📋</span>
              Últimas operações
            </CardTitle>
          </CardHeader>
          <CardContent>
            {latestOperations.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">
                Ainda não há operações de dígitos concluídas nesta consulta.
              </p>
            ) : (
              <>
                <div className="hidden sm:block overflow-x-auto rounded-lg border border-border">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border bg-muted/40 text-left text-xs text-muted-foreground">
                        <th className="px-3 py-2 font-medium">Data</th>
                        <th className="px-3 py-2 font-medium">Tipo</th>
                        <th className="px-3 py-2 font-medium">Símbolo</th>
                        <th className="px-3 py-2 font-medium text-right">Stake</th>
                        <th className="px-3 py-2 font-medium text-right">Venda</th>
                        <th className="px-3 py-2 font-medium text-right">P&amp;L</th>
                      </tr>
                    </thead>
                    <tbody>
                      {latestOperations.map((pos) => {
                        const profit = pos.sell_price - pos.buy_price;
                        const won = profit >= 0;
                        return (
                          <tr
                            key={pos.contract_id}
                            className="border-b border-border/60 last:border-0"
                          >
                            <td className="px-3 py-2 tabular-nums text-muted-foreground whitespace-nowrap">
                              {formatDateTime(pos.sell_time)}
                            </td>
                            <td className="px-3 py-2 font-medium">
                              {digitContractLabels[pos.contract_type] ??
                                pos.contract_type}
                            </td>
                            <td className="px-3 py-2 text-muted-foreground">
                              {getSymbolDisplayName(pos.underlying_symbol)}
                            </td>
                            <td className="px-3 py-2 text-right tabular-nums">
                              {formatMoney(pos.buy_price)}
                            </td>
                            <td className="px-3 py-2 text-right tabular-nums">
                              {formatMoney(pos.sell_price)}
                            </td>
                            <td
                              className={cn(
                                'px-3 py-2 text-right font-semibold tabular-nums',
                                won ? 'text-emerald-500' : 'text-destructive'
                              )}
                            >
                              {won ? '+' : ''}
                              {formatMoney(profit)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                <div className="sm:hidden flex flex-col gap-2">
                  {latestOperations.map((pos) => {
                    const profit = pos.sell_price - pos.buy_price;
                    const won = profit >= 0;
                    return (
                      <div
                        key={pos.contract_id}
                        className="rounded-lg border border-border bg-card p-3 space-y-1.5"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold">
                            {digitContractLabels[pos.contract_type] ??
                              pos.contract_type}
                          </span>
                          <span
                            className={cn(
                              'text-sm font-bold tabular-nums',
                              won ? 'text-emerald-500' : 'text-destructive'
                            )}
                          >
                            {won ? '+' : ''}
                            {formatMoney(profit)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>
                            {getSymbolDisplayName(pos.underlying_symbol)}
                          </span>
                          <span className="tabular-nums">
                            {formatDateTime(pos.sell_time)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>
                            Stake {formatMoney(pos.buy_price)} → Venda{' '}
                            {formatMoney(pos.sell_price)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <p className="mt-3 text-xs text-muted-foreground">
                  Mostrando as {latestOperations.length} operações de dígitos
                  mais recentes (entre as carregadas).
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <PositionsTable
          openPositions={digitOpenPositions}
          closedPositions={digitClosedPositions}
          onSell={trading.sellContract}
          sellingId={trading.sellingId}
          sellError={trading.sellError}
          onClearSellError={trading.clearSellError}
          contractTypeLabels={digitContractLabels}
          className="mt-0"
        />
      </div>

      <div className="fixed bottom-0 left-0 right-0 py-2 text-center bg-background/80 backdrop-blur-sm">
        <Footer />
      </div>
    </main>
  );
}
