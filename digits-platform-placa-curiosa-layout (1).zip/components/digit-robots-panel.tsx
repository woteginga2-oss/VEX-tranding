 'use client';
import { useEffect, useRef, useState } from 'react';
import { Bot, CheckCircle2, XCircle, Play, Square } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Tick } from '@deriv/core';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
type RobotResult = { wins: number; losses: number; last: 'WIN' | 'LOSS' | null };

function RobotCard({ name, description, digits, lastDigit, result, running, stake, setStake, stopLoss, setStopLoss, takeProfit, setTakeProfit }: {
  name: string; description: string; digits: number[]; lastDigit: number | null; result: RobotResult;
  running: boolean; stake: string; setStake: (v: string) => void;
  stopLoss: string; setStopLoss: (v: string) => void; takeProfit: string; setTakeProfit: (v: string) => void;
}) {
  return (
    <Card className="border-slate-700/60 bg-[#11161d] text-slate-100 shadow-sm rounded-[20px]">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-base">
          <span className="flex items-center gap-2"><Bot className="h-4 w-4 text-primary" />{name}</span>
          <Badge variant={running ? 'default' : 'secondary'}>{running ? 'MONITORIZAÇÃO ATIVA' : 'PARADO'}</Badge>
        </CardTitle>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-1.5">
          {digits.map((digit) => <span key={digit} className={`flex h-7 w-7 items-center justify-center rounded-md text-xs font-bold ${lastDigit === digit ? 'bg-primary text-primary-foreground ring-2 ring-primary/30' : 'bg-muted text-muted-foreground'}`}>{digit}</span>)}
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-xl border border-emerald-500/15 bg-emerald-500/[0.08] p-3"><div className="flex items-center gap-1 text-xs text-emerald-600"><CheckCircle2 className="h-3.5 w-3.5" /> SINAIS CERTOS</div><div className="text-xl font-bold tabular-nums">{result.wins}</div></div>
          <div className="rounded-xl border border-rose-500/15 bg-rose-500/[0.08] p-3"><div className="flex items-center gap-1 text-xs text-red-500"><XCircle className="h-3.5 w-3.5" /> SINAIS FALHADOS</div><div className="text-xl font-bold tabular-nums">{result.losses}</div></div>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <label className="space-y-1 text-xs font-medium text-muted-foreground">Stake (USD)
            <input type="number" min="0.35" step="0.01" value={stake} onChange={e => setStake(e.target.value)} className="mt-1 h-10 w-full rounded-lg border border-slate-700 bg-[#090d12] px-3 text-sm text-slate-100 outline-none focus:ring-2 focus:ring-emerald-500/40" />
          </label>
          <label className="space-y-1 text-xs font-medium text-muted-foreground">Stop Loss (USD)
            <input type="number" min="0" step="0.01" value={stopLoss} onChange={e => setStopLoss(e.target.value)} className="mt-1 h-10 w-full rounded-lg border border-slate-700 bg-[#090d12] px-3 text-sm text-slate-100 outline-none focus:ring-2 focus:ring-emerald-500/40" />
          </label>
          <label className="space-y-1 text-xs font-medium text-muted-foreground">Take Profit (USD)
            <input type="number" min="0" step="0.01" value={takeProfit} onChange={e => setTakeProfit(e.target.value)} className="mt-1 h-10 w-full rounded-lg border border-slate-700 bg-[#090d12] px-3 text-sm text-slate-100 outline-none focus:ring-2 focus:ring-emerald-500/40" />
          </label>
        </div>
        <div className="flex items-center justify-between gap-3 border-t border-border pt-3">
          <p className="text-xs text-muted-foreground">Último sinal: <span className="font-semibold text-foreground">{result.last ?? '—'}</span></p>
          <span className="text-xs font-semibold text-muted-foreground">{running ? 'Robô selecionado em execução' : 'Pronto para iniciar'}</span>
        </div>
      </CardContent>
    </Card>
  );
}

export function DigitRobotsPanel({ lastDigit, currentTick }: { lastDigit: number | null; currentTick: Tick | null }) {
  const [selectedRobot, setSelectedRobot] = useState<'mafs' | 'pares'>('mafs');
  const [mafsRunning, setMafsRunning] = useState(false);
  const [paresRunning, setParesRunning] = useState(false);
  const [mafsStake, setMafsStake] = useState('1.00');
  const [mafsStopLoss, setMafsStopLoss] = useState('10.00');
  const [mafsTakeProfit, setMafsTakeProfit] = useState('20.00');
  const [paresStake, setParesStake] = useState('1.00');
  const [paresStopLoss, setParesStopLoss] = useState('10.00');
  const [paresTakeProfit, setParesTakeProfit] = useState('20.00');
  const [mafs, setMafs] = useState<RobotResult>({ wins: 0, losses: 0, last: null });
  const [pares, setPares] = useState<RobotResult>({ wins: 0, losses: 0, last: null });
  const previousQuote = useRef<string | null>(null);

  useEffect(() => {
    if ((!mafsRunning && !paresRunning) || !currentTick || lastDigit === null) return;
    // Deriv pode emitir vários ticks no mesmo segundo. O ID identifica cada
    // cotação individual; o fallback mantém compatibilidade com ticks antigos.
    const tickId = currentTick.id || `${currentTick.epoch}:${currentTick.quote}`;
    if (previousQuote.current === tickId) return;
    previousQuote.current = tickId;
    if (mafsRunning) {
      const hit = [4, 5, 6, 7, 8, 9].includes(lastDigit);
      setMafs(old => ({ wins: old.wins + Number(hit), losses: old.losses + Number(!hit), last: hit ? 'WIN' : 'LOSS' }));
    }
    if (paresRunning) {
      const hit = [2, 4, 6, 8].includes(lastDigit);
      setPares(old => ({ wins: old.wins + Number(hit), losses: old.losses + Number(!hit), last: hit ? 'WIN' : 'LOSS' }));
    }
  }, [mafsRunning, paresRunning, currentTick, lastDigit]);

  return (
    <section className="space-y-3 text-slate-100">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div><h2 className="text-lg font-semibold">Central de robôs</h2><p className="text-xs text-muted-foreground">Configure cada estratégia e controle a monitorização.</p></div>
        <Badge variant={mafsRunning || paresRunning ? 'default' : 'secondary'}>{mafsRunning || paresRunning ? 'SISTEMA ATIVO' : 'SISTEMA EM ESPERA'}</Badge>
      </div>
      <div className="rounded-xl border border-amber-500/25 bg-amber-500/[0.07] p-3 text-xs text-slate-400">
        Importante: Stake, Stop Loss e Take Profit ficam configurados na interface. Nesta versão, os robôs monitorizam sinais e não enviam ordens reais nem aplicam limites financeiros automaticamente. Para operar na Deriv, é necessário ligar a execução de contratos e o controlo de saldo.
      </div>
      <div className="rounded-[22px] border border-slate-700/60 bg-[#11161d] p-4 space-y-4 shadow-[0_8px_24px_rgba(0,0,0,0.2)]">
        <label className="block space-y-2 text-sm font-medium">Escolher robô
          <select value={selectedRobot} onChange={e => setSelectedRobot(e.target.value as 'mafs' | 'pares')} className="h-11 w-full rounded-xl border border-slate-700 bg-[#090d12] px-3 text-slate-100">
            <option value="mafs">Mafs — dígitos 4, 5, 6, 7, 8 e 9</option>
            <option value="pares">Pares — dígitos 2, 4, 6 e 8</option>
          </select>
        </label>
        {selectedRobot === 'mafs'
          ? <RobotCard name="Mafs" description="Estratégia: operar quando o último dígito for 4, 5, 6, 7, 8 ou 9" digits={[4,5,6,7,8,9]} lastDigit={lastDigit} result={mafs} running={mafsRunning} stake={mafsStake} setStake={setMafsStake} stopLoss={mafsStopLoss} setStopLoss={setMafsStopLoss} takeProfit={mafsTakeProfit} setTakeProfit={setMafsTakeProfit} />
          : <RobotCard name="Pares" description="Estratégia: operar quando o último dígito for 2, 4, 6 ou 8" digits={[2,4,6,8]} lastDigit={lastDigit} result={pares} running={paresRunning} stake={paresStake} setStake={setParesStake} stopLoss={paresStopLoss} setStopLoss={setParesStopLoss} takeProfit={paresTakeProfit} setTakeProfit={setParesTakeProfit} />}
        <div className="border-t border-slate-700/70 pt-3 flex justify-end">
          {(selectedRobot === 'mafs' ? mafsRunning : paresRunning)
            ? <Button type="button" variant="destructive" onClick={() => selectedRobot === 'mafs' ? setMafsRunning(false) : setParesRunning(false)}><Square className="mr-2 h-4 w-4" /> PARAR ROBÔ</Button>
            : <Button type="button" onClick={() => selectedRobot === 'mafs' ? setMafsRunning(true) : setParesRunning(true)}><Play className="mr-2 h-4 w-4" /> INICIAR ROBÔ</Button>}
        </div>
      </div>
    </section>
  );
}
