'use client';

import { cn } from '@/lib/utils';
import type { DigitStats } from '../lib/types';

interface DigitStatsBarProps {
  digitStats: DigitStats;
  selectedDigit: number;
  lastDigit?: number | null;
  onDigitSelect: (digit: number) => void;
}

export function DigitStatsBar({ digitStats, selectedDigit, lastDigit, onDigitSelect }: DigitStatsBarProps) {
  const maxPct = Math.max(...digitStats.percentages, 1);

  return (
    <div className="flex min-h-0 flex-col">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <span className="text-sm font-medium text-foreground">
          Último dígito: <strong className="text-emerald-400">{lastDigit ?? '—'}</strong>
        </span>
        <span className="rounded-md bg-[#090d12] px-3 py-1.5 text-xs text-slate-400">
          {digitStats.totalTicks} ticks
        </span>
      </div>
      <div className="flex h-48 items-end gap-1 border-b border-slate-700/70 px-1 sm:h-56 sm:gap-2">
        {digitStats.percentages.map((pct, digit) => {
          const selected = digit === selectedDigit;
          const height = digitStats.totalTicks > 0 ? Math.max(3, (pct / maxPct) * 100) : 3;
          const rare = pct > 0 && pct <= 5;
          return (
            <button
              key={digit}
              type="button"
              onClick={() => onDigitSelect(digit)}
              aria-label={`Selecionar dígito ${digit}: ${pct.toFixed(1)}%`}
              className="group flex h-full min-w-0 flex-1 flex-col items-center justify-end gap-2 outline-none"
            >
              <span className="text-[10px] font-medium tabular-nums text-slate-400 sm:text-xs">
                {pct.toFixed(1)}%
              </span>
              <span
                className={cn(
                  'w-full max-w-12 rounded-t-md transition-[height,background-color,opacity] duration-300 ease-out',
                  selected ? 'bg-emerald-500' : rare ? 'bg-rose-500' : 'bg-slate-500/60',
                  selected && 'shadow-[0_0_16px_rgba(16,185,129,0.22)]'
                )}
                style={{ height: `${height}%`, opacity: selected ? 1 : 0.9 }}
              />
              <span className={cn('pb-2 text-xs font-semibold', selected ? 'text-emerald-400' : 'text-slate-400')}>
                {digit}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
