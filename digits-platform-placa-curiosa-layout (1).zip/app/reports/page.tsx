'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Localize } from '@deriv-com/translations';
import { useDigitsTrading } from '../../hooks/use-digits-trading';
import { useDerivWSContext } from '@/components/custom/deriv-ws-provider';
import { useLogoSrc } from '@/components/custom/logo-src-provider';
import { Header } from '@/components/custom/header';
import { ThemeToggle } from '@/components/custom/theme-toggle';
import { Footer } from '@/components/custom/footer';
import { useAppTranslations } from '@/components/custom/i18n-provider';
import Link from 'next/link';
import { PositionsTable } from '@/components/custom/positions-table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const DIGIT_CONTRACT_TYPES = [
  'DIGITMATCH',
  'DIGITDIFF',
  'DIGITOVER',
  'DIGITUNDER',
  'DIGITEVEN',
  'DIGITODD',
] as const;

function getDigitContractLabels(
  localize: (text: string) => string
): Record<string, string> {
  return {
    DIGITMATCH: localize('Digit Match'),
    DIGITDIFF: localize('Digit Differs'),
    DIGITOVER: localize('Digit Over'),
    DIGITUNDER: localize('Digit Under'),
    DIGITEVEN: localize('Digit Even'),
    DIGITODD: localize('Digit Odd'),
  };
}

export default function ReportsPage() {
  const logoSrc = useLogoSrc();
  const router = useRouter();
  const { localize } = useAppTranslations();
  const { ws, isConnected, isExhausted, auth } = useDerivWSContext();
  const { authState, accounts, activeAccount, login, signUp, logout, switchAccount } = auth;
  const trading = useDigitsTrading({ ws, isConnected, isExhausted, isAuthenticated: !!auth.wsUrl, onAuthWSFailed: logout });
  const digitContractLabels = getDigitContractLabels(localize);
  const digitOpenPositions = trading.openPositions.filter(p =>
    (DIGIT_CONTRACT_TYPES as readonly string[]).includes(p.contract_type)
  );
  const digitClosedPositions = trading.closedPositions.filter(p =>
    (DIGIT_CONTRACT_TYPES as readonly string[]).includes(p.contract_type)
  );

  useEffect(() => {
    if (authState === 'unauthenticated' || authState === 'error') {
      router.replace('/');
    }
  }, [authState, router]);

  if (authState !== 'authenticated') {
    return (
      <main className="flex flex-col bg-background items-center justify-center min-h-dvh">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </main>
    );
  }

  return (
    <main className="flex flex-col bg-background max-lg:h-dvh max-lg:overflow-y-auto lg:min-h-dvh">
      <Header
        authState={authState}
        accounts={accounts}
        activeAccount={activeAccount}
        onLogin={login}
        onSignUp={signUp}
        onLogout={logout}
        onSwitchAccount={switchAccount}
        logoSrc={logoSrc}
        actions={<ThemeToggle />}
      />

      <div className="flex-1 w-full max-w-7xl mx-auto px-3 py-4 sm:px-4 sm:py-6 pb-14">
        <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-4">
          <span className="text-base leading-none">←</span>
          <span>
            <Localize i18n_default_text="Back" />
          </span>
        </Link>
        <Card className="mb-4">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <span aria-hidden="true">🏆</span>
              Ranking de operações
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="rounded-lg bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">Operações concluídas carregadas (máx. 500)</p>
                <p className="mt-1 text-2xl font-bold tabular-nums">{trading.closedPositionCount}</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">Operações de dígitos abertas</p>
                <p className="mt-1 text-2xl font-bold tabular-nums">{digitOpenPositions.length}</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">Operações de dígitos entre as carregadas</p>
                <p className="mt-1 text-2xl font-bold tabular-nums">{digitClosedPositions.length}</p>
              </div>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">Os números refletem o histórico carregado pela API (até 500 operações concluídas nesta consulta) e as posições de dígitos abertas. Isto é um resumo da conta autenticada, não uma classificação pública entre utilizadores; um ranking global exigiria um serviço partilhado e consentimento dos participantes.</p>
          </CardContent>
        </Card>
        <PositionsTable
          openPositions={digitOpenPositions}
          closedPositions={digitClosedPositions}
          onSell={trading.sellContract}
          sellingId={trading.sellingId}
          sellError={trading.sellError}
          onClearSellError={trading.clearSellError}
          contractTypeLabels={digitContractLabels}
          className="mt-0"
        />
      </div>

      {/* Fixed footer */}
      <div className="fixed bottom-0 left-0 right-0 py-2 text-center bg-background/80 backdrop-blur-sm">
        <Footer />
      </div>
    </main>
  );
}
